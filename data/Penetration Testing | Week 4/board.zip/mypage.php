<?php
session_start();
require_once 'db.php';

if (isset($_SESSION['username'])) {
  $username = $_SESSION['username'];

  $sql = "SELECT name, email, username FROM users WHERE username = '$username'";
  $result = mysqli_query($db_conn, $sql);

  if (mysqli_num_rows($result) == 1) {
      $user = mysqli_fetch_array($result);
  } else {
      echo "You must log in first.";
      exit;
  }
}
?>

<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>My Page</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="sign_up.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <div class="content">
      <a href="index.php" class="back-button">⬅</a>

      <h1>My Page</h1>

      <div class="user-info">
        <p><strong>Name:</strong> <?= $user['name'] ?></p>
        <p><strong>Email:</strong> <?= $user['email'] ?></p>
        <p><strong>Username:</strong> <?= $user['username'] ?></p>
      </div>
    </div>
  </main>

</body>

</html>