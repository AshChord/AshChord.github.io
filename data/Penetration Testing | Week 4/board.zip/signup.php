<?php
require_once 'db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $username = $_POST['username'];
  $password = $_POST['password'];

  if ($username) {
    $sql_check = "SELECT * FROM users WHERE username = '$username'";
    $result_check = mysqli_query($db_conn, $sql_check);

    if (mysqli_num_rows($result_check) > 0) {
      $message = "<p style='color: red;'>Username already exists. Please choose a different username.</p>";
    } else {
      $hashed_password = hash('sha256', $password);

      $sql_insert = "INSERT INTO users (name, email, username, password) VALUES ('$name', '$email', '$username', '$hashed_password')";
      $result_insert = mysqli_query($db_conn, $sql_insert);

      if ($result_insert) {
        header("Location: index.php");
        exit;
      } else {
        $message = "<p style='color: red;'>An error occurred while signing up. Please try again.</p>";
      }
    }
  }
}
?>

<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sign Up</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="signup.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <div class="content">
      <a href="index.php" class="back-button">⬅</a>

      <h1>Sign Up</h1>

      <form method="POST">
        <input type="text" name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" class="signup-button">Sign Up</button>

        <p>Already have an account? Click the <strong><em>Log In</em></strong> button at the top right.</p>
        <?php if ($message) { echo $message; } ?>
      </form>
    </div>
  </main>

</body>

</html>