<?php
require_once 'db.php';

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['username'];
  $password = hash('sha256', $_POST['password']);

  $sql = "SELECT * FROM users WHERE username = '$username'";
  $res = mysqli_query($db_conn, $sql);

  if (mysqli_num_rows($res) == 1) {
    $user = mysqli_fetch_array($res);

    if ($user['password'] === $password) {
      session_start();
      $_SESSION['user_id'] = $user['id'];
      $_SESSION['username'] = $user['username'];
      header("Location: index.php");
      exit;
    } else {
      $message = "<p style='color: red;'>Login failed. Please try again.</p>";
    }
  } else {
    $message = "<p style='color: red;'>Login failed. Please try again.</p>";
  }
}
?>

<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Log In</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="signup.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <div class="content">
      <a href="index.php" class="back-button">⬅</a>

      <h1>Log In</h1>
      
      <form action="login.php" method="POST">
        <input type="text" name="username" placeholder="ID" required>
        <input type="password" name="password" placeholder="PW" required>
        <button type="submit" class="login-button">Login</button>

        <p>Don't have an account? Click the <strong><em>Sign Up</em></strong> button at the top right.</p>
        <?php if ($message) { echo $message; } ?>
      </form>
    </div>
  </main>

</body>

</html>
