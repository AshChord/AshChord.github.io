<?php
session_start();
require_once 'db.php';

if (isset($_GET['id'])) {
  $post_id = $_GET['id'];
  $sql = "SELECT * FROM posts WHERE id = $post_id";
  $result = mysqli_query($db_conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $post = mysqli_fetch_array($result);

    if ($_SESSION['username'] === $post['author']) {
      $sql_delete = "DELETE FROM posts WHERE id = $post_id";
      $result_delete = mysqli_query($db_conn, $sql_delete);

      if ($result_delete) {
        header("Location: index.php");
        exit;
      }
    }
  }
}
?>