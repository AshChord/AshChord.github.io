<?php
session_start();
require_once 'db.php';

$sql = "SELECT id, title, author, created_at FROM posts ORDER BY id DESC";
$result = mysqli_query($db_conn, $sql);
?>

<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Bulletin Board</title>
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="signup.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <table>
      <thead>
        <tr>
          <th>No.</th>
          <th>Title</th>
          <th>Author</th>
          <th>Created at</th>
        </tr>
      </thead>
      <tbody>
        <?php while ($row = mysqli_fetch_array($result)) { ?>
          <tr>
            <td><a href="view.php?id=<?= $row['id'] ?>"><?= $row['id'] ?></td>
            <td><a href="view.php?id=<?= $row['id'] ?>"><?= $row['title'] ?></a></td>
            <td><a href="view.php?id=<?= $row['id'] ?>"><?= $row['author'] ?></td>
            <td><a href="view.php?id=<?= $row['id'] ?>"><?= $row['created_at'] ?></td>
          </tr>
        <?php } ?>
      </tbody>
    </table>

    <?php if (isset($_SESSION['username'])) { ?>
      <a href="write.php" class="write-button">New Post</a>
    <?php } ?>
  </main>

</body>

</html>