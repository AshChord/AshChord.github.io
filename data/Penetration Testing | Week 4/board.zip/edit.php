<?php
session_start();
require_once 'db.php';

if (isset($_GET['id'])) {
  $post_id = $_GET['id'];
  $sql = "SELECT * FROM posts WHERE id = $post_id";
  $result = mysqli_query($db_conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $post = mysqli_fetch_array($result);
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $title = $_POST['title'];
  $content = $_POST['content'];
  
  $sql_update = "UPDATE posts SET title = '$title', content = '$content' WHERE id = $post_id";
  $result_update = mysqli_query($db_conn, $sql_update);

  if ($result_update) {
    header("Location: view.php?id=$post_id");
    exit;
  }
}
?>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="signup.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <div class="content">
      <a href="index.php" class="back-button">⬅</a>

      <h1>Edit Post</h1>

      <form method="POST">
        <input type="text" name="title" placeholder="Title" value="<?= $post['title'] ?>" required>
        <textarea name="content" placeholder="Content" required><?= $post['content'] ?></textarea>
        <button type="submit" class="submit-button">Update Post</button>
      </form>
    </div>
  </main>

</body>

</html>