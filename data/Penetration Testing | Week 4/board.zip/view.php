<?php
session_start();
require_once 'db.php';

if (isset($_GET['id'])) {
  $post_id = $_GET['id'];
  $sql = "SELECT * FROM posts WHERE id = $post_id";
  $result = mysqli_query($db_conn, $sql);

  if (mysqli_num_rows($result) == 1) {
    $post = mysqli_fetch_array($result);
  }
}
?>

<!DOCTYPE html>
<html lang="ko">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>View</title>
  <link rel="stylesheet" href="style.css" />
</head>

<body>

  <header>
    <div class="title">Bulletin Board</div>

    <div class="user-menu">
      <?php if (isset($_SESSION['username'])) { ?>
        <button class="user-button"><?= $_SESSION['username'] ?> ▼</button>
        <div class="user-panel">
          <a href="mypage.php">My Page</a>
          <a href="logout.php">Log Out</a>
        </div>
      <?php } else { ?>
        <a href="login.php" class="auth-button">Log In</a>
        <a href="signup.php" class="auth-button">Sign Up</a>
      <?php } ?>
    </div>
  </header>

  <main>
    <div class="content">
      <a href="index.php" class="back-button">⬅</a>

      <h1><?= $post['title'] ?></h1>
      <section>
        <p><strong>Author:</strong> <?= $post['author'] ?> | <strong>Created at:</strong> <?= $post['created_at'] ?></p>
        <hr>
        <p><?= $post['content'] ?></p>
      </section>

      <?php
      if (isset($_SESSION['username']) && $_SESSION['username'] === $post['author']) {
      ?>
        <div class="post-actions">
          <a href="edit.php?id=<?= $post['id'] ?>" class="post-button">Edit</a>
          <a href="delete.php?id=<?= $post['id'] ?>" class="post-button" onclick="return confirm('Are you sure you want to delete this post?')">Delete</a>
        </div>
      <?php } ?>
    </div>

  </main>
</body>

</html>